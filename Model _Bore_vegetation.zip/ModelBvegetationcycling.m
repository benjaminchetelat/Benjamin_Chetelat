
global teta betadecwood fT T H alpha2 kexB Hw  Jmax Bmin Km  Prec KS eta a b c Infil   t Hs X  ker alpha1 betadec DEMm  aa bb   xin kll kwl  fex fw fl  kl kw beta2 dt Ratm  Atm  Rcw CW alpha

ta = 25; %temperature degree Celcius)
Tk = 273.15 + ta;

 
% Atmospheric inputs
 
Atm =0.00003; %molB/m2/yr
 
%Soil constants
 
teta = 0.3; %Porosity

 
%Drainage 
c = 12;
KS =  300; %m/yr

 
%Maximum transpiration rate
eta = 0.8; %m/yr

 
% Litter decay parameters (Lloyd and Taylor, 1994; Braakhekke et al. 2011)
Ea = 308.56; %K
T0 =227.13; %K
Tref = 283.15; %K
a = 1;
b = 20;
fT= exp(Ea*(1/(Tref-T0)-1/(Tk-T0)));

% Litter decay rates
kll = 0.3; %yr-1
kwl = kll/50; %yr-1

% allocation Vegetation parameters
fex = 0.5;
fw = 0.037;
fl = 1-(fw+fex);
rap =8; %ratio of wood/leak stocks
 
 
% Leaves and wood turnover rate

kl = 1; %yr-1;
kw = kl/100; %yr-1;
kexB = 0.; %yr-1

% Loss rate by erosion
ker = 0.;%yr-1;


 
% B isotopic ratio
Rstd = 4.04356;
Rcw = 4.04356;%Bedrock inputs -7 permil
Ratm = 4.125;%Atmospheric inputs 20 permil

% Isotopic fractionation factors
alpha1 = 0.973; %iso fract wood
alpha2 = 0.99; %iso fract leaf
alpha = 0.975;
beta2 =1; %isotopic fractionation uptake
betadec = 1.01;
betadecwood = 1.;
 
T =15;
Tsol = 50;
t=0.001;
H =1; 
Hs =0.001;
Hsmax=0.15;
Hw = 1;
dt = 2;
lb = [0, 0, 0, 3, 0, 3, 0, 0 3];
ub = [1 1 Inf 5 Inf 5 1 Inf 5];
loop =0;
Infil =1;
 CW= Atm*40; %mol/m2/yr
  Prec =0.*(CW+Atm);
  
 % Uptake parameters
 DEMm = 0.003;
    Jmax =20*10^(-3);
     Bmin = 10^(-6);
    Km = 2*10^(-3);
    aa =0;
    bb =0;
    X = 0.5; 
    
allocation_wood = 'constant'; % Method to allocate boron to the woody part

if allocation_wood == 'constant'

xin = [0.5 0.5 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm) 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm) 0.5 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm)];
n = 500;
x0 = xin;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = 0;
xx(1,:) = xin;


options_l = optimoptions(@lsqnonlin,'TolFun',1e-6,'TolX',1e-12);

   
    
    
 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layerdynhydro',x0,lb,ub,options_l);
   x0 = xxx;
   xx(i+1,:) =fsolve('Bveg3layerdynhydro',x0);
   
   
    xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

tm(i+1) = tm(i)+dt;
loop = loop + 1

 end


options = optimoptions('fsolve','FiniteDifferenceType','central','TolFun',1e-9,'TolX',1e-12,'MaxIter',10000);
xin = [xx(end,3) 0.000000001 0.000000001 0.000000001 0.000000001 xx(end,4) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) xx(end,5) xx(end,6) xx(end,1) xx(end,2) xx(end,7) xx(end,8) xx(end,9)];
lb = [0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 0,3, 0,0, 0, 0, 3 ];
ub = [Inf Inf Inf Inf Inf 5 5 5 5 5 Inf 5 1 1 1 Inf 5];
dt =0.0001;
t = 0.0001;
n = 100000;

x0 = xin;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = 0;
xx(1,:) = xin;
resisual_tot_1 = zeros(n+1,length(xin));
resinorm_tot_1 = zeros(n+1,1);
exitflag_tot_lsqnonlin_1 = zeros(n+1,1);
exitflag_tot_fslv_1 = zeros(n+1,1);
fval_tot_1= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fw;
Horg = zeros(n+1,1);
Horg(1) = Hs;
   

    
uptake = zeros(n+1,2);
uptake(1,1)= aa;
uptake(1,2)= bb;

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_1(i,:) = residual;
   resinorm_tot_1(i) = resnorm;
   exitflag_tot_lsqnonlin_1(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_1(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_1(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));
 
 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_1 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_1(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_1(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end

xxend = xx(end,:);
tm_end =tm(end);
d11Bex_end = d11Bex(end);
Upttot_end = Upttot(end);
 UptSOL_end = UptSOL(end);
UptSML_end = UptSML(end);
 d11BuptSOL_end = d11BuptSOL(end) ;
 d11BuptSML_end =d11BuptSML(end);
uptake_end =uptake(end,:);

dt = 0.001;
n =30000;
xin = xxend;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = tm_end;
xx(1,:) = xin;
resisual_tot_2 = zeros(n+1,length(xin));
resinorm_tot_2 = zeros(n+1,1);
exitflag_tot_lsqnonlin_2 = zeros(n+1,1);
exitflag_tot_fslv_2 = zeros(n+1,1);
fval_tot_2= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
d11Bex(1) = d11Bex_end;
Upttot(1) = Upttot_end;
UptSOL(1) = UptSOL_end;
UptSML(1) = UptSML_end;
d11BuptSOL(1) = d11BuptSOL_end;
d11BuptSML(1) = d11BuptSML_end ;


options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fw;
Horg = zeros(n+1,1);
Horg(1) = Hs;
   

    
uptake = zeros(n+1,2);
uptake(1,1)= uptake_end(1,1);
uptake(1,2)= uptake_end(1,2);

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_2(i,:) = residual;
   resinorm_tot_2(i) = resnorm;
   exitflag_tot_lsqnonlin_2(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_2(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_2(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));

 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_2 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_2(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_2(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end
xxend = xx(end,:);
tm_end =tm(end);
d11Bex_end = d11Bex(end);
Upttot_end = Upttot(end);
 UptSOL_end = UptSOL(end);
UptSML_end = UptSML(end);
 d11BuptSOL_end = d11BuptSOL(end) ;
 d11BuptSML_end =d11BuptSML(end);
uptake_end =uptake(end,:);

dt = 0.1;
n =30000;
xin = xxend;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = tm_end;
xx(1,:) = xin;
resisual_tot_3 = zeros(n+1,length(xin));
resinorm_tot_3 = zeros(n+1,1);
exitflag_tot_lsqnonlin_3 = zeros(n+1,1);
exitflag_tot_fslv_3 = zeros(n+1,1);
fval_tot_3= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
d11Bex(1) = d11Bex_end;
Upttot(1) = Upttot_end;
UptSOL(1) = UptSOL_end;
UptSML(1) = UptSML_end;
d11BuptSOL(1) = d11BuptSOL_end;
d11BuptSML(1) = d11BuptSML_end ;
options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fw;
Horg = zeros(n+1,1);
Horg(1) = Hs;
   
    
    
uptake = zeros(n+1,2);
uptake(1,1)= uptake_end(1,1);
uptake(1,2)= uptake_end(1,2);

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_3(i,:) = residual;
   resinorm_tot_3(i) = resnorm;
   exitflag_tot_lsqnonlin_3(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_3(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_3(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));

 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_3 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_3(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_3(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end

Resultat_tot = [Resultat_1;Resultat_2;Resultat_3];

end

if allocation_wood == 'variable'
    
xin = [0.5 0.5 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm) 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm) 0.5 0.000001 (Rcw*CW+Ratm*Atm)/(CW+Atm)];
n = 500;

x0 = xin;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = 0;
xx(1,:) = xin;


options_l = optimoptions(@lsqnonlin,'TolFun',1e-6,'TolX',1e-12);

   
    
    
 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layerdynhydro',x0,lb,ub,options_l);
   x0 = xxx;
   xx(i+1,:) =fsolve('Bveg3layerdynhydro',x0);
   
   
    xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

tm(i+1) = tm(i)+dt;
loop = loop + 1

 end


options = optimoptions('fsolve','FiniteDifferenceType','central','TolFun',1e-9,'TolX',1e-12,'MaxIter',10000);
xin = [xx(end,3) 0.000000001 0.000000001 0.000000001 0.000000001 xx(end,4) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) (Rcw*CW+Ratm*Atm)/(CW+Atm) xx(end,5) xx(end,6) xx(end,1) xx(end,2) xx(end,7) xx(end,8) xx(end,9)];
lb = [0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 0,3, 0,0, 0, 0, 3 ];
ub = [Inf Inf Inf Inf Inf 5 5 5 5 5 Inf 5 1 1 1 Inf 5];
dt =0.0001;
t = 0.0001;
n = 100000;

x0 = xin;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = 0;
xx(1,:) = xin;
resisual_tot_1 = zeros(n+1,length(xin));
resinorm_tot_1 = zeros(n+1,1);
exitflag_tot_lsqnonlin_1 = zeros(n+1,1);
exitflag_tot_fslv_1 = zeros(n+1,1);
fval_tot_1= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fw;
Horg = zeros(n+1,1);
Horg(1) = Hs;
   
    
    
uptake = zeros(n+1,2);
uptake(1,1)= aa;
uptake(1,2)= bb;

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_1(i,:) = residual;
   resinorm_tot_1(i) = resnorm;
   exitflag_tot_lsqnonlin_1(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_1(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_1(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));

  fw = (kw*xx(i+1,2)+rap*(1-fex)*Upttot(i+1,1)-rap*kl*xx(i+1,3))/((rap+1)*Upttot(i+1,1));
 fl=1-fex-fw; 
 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_1 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_1(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_1(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end

xxend = xx(end,:);
tm_end =tm(end);
d11Bex_end = d11Bex(end);
Upttot_end = Upttot(end);
 UptSOL_end = UptSOL(end);
UptSML_end = UptSML(end);
 d11BuptSOL_end = d11BuptSOL(end) ;
 d11BuptSML_end =d11BuptSML(end);
uptake_end =uptake(end,:);
fractwood_end = fractwood(end);


dt = 0.001;
n =30000;
xin = xxend;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = tm_end;
xx(1,:) = xin;
resisual_tot_2 = zeros(n+1,length(xin));
resinorm_tot_2 = zeros(n+1,1);
exitflag_tot_lsqnonlin_2 = zeros(n+1,1);
exitflag_tot_fslv_2 = zeros(n+1,1);
fval_tot_2= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
d11Bex(1) = d11Bex_end;
Upttot(1) = Upttot_end;
UptSOL(1) = UptSOL_end;
UptSML(1) = UptSML_end;
d11BuptSOL(1) = d11BuptSOL_end;
d11BuptSML(1) = d11BuptSML_end ;


options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fractwood_end;
Horg = zeros(n+1,1);
Horg(1) = Hs;

    
uptake = zeros(n+1,2);
uptake(1,1)= uptake_end(1,1);
uptake(1,2)= uptake_end(1,2);

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_2(i,:) = residual;
   resinorm_tot_2(i) = resnorm;
   exitflag_tot_lsqnonlin_2(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_2(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_2(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));

fw = (kw*xx(i+1,2)+rap*(1-fex)*Upttot(i+1,1)-rap*kl*xx(i+1,3))/((rap+1)*Upttot(i+1,1));
 fl=1-fex-fw;  
 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_2 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_2(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_2(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end
xxend = xx(end,:);
tm_end =tm(end);
d11Bex_end = d11Bex(end);
Upttot_end = Upttot(end);
 UptSOL_end = UptSOL(end);
UptSML_end = UptSML(end);
 d11BuptSOL_end = d11BuptSOL(end) ;
 d11BuptSML_end =d11BuptSML(end);
uptake_end =uptake(end,:);
fractwood_end = fractwood(end);


dt = 0.1;
n =30000;
xin = xxend;
xx = zeros(n+1,length(xin));
tm = zeros(n+1,1);
tm(1) = tm_end;
xx(1,:) = xin;
resisual_tot_3 = zeros(n+1,length(xin));
resinorm_tot_3 = zeros(n+1,1);
exitflag_tot_lsqnonlin_3 = zeros(n+1,1);
exitflag_tot_fslv_3 = zeros(n+1,1);
fval_tot_3= zeros(length(xin),n+1);
d11Bex = zeros(n+1,1);
Upttot = zeros(n+1,1);
UptSOL = zeros(n+1,1);
UptSML = zeros(n+1,1);
d11BuptSOL = zeros(n+1,1);
d11BuptSML = zeros(n+1,1);
d11Bex(1) = d11Bex_end;
Upttot(1) = Upttot_end;
UptSOL(1) = UptSOL_end;
UptSML(1) = UptSML_end;
d11BuptSOL(1) = d11BuptSOL_end;
d11BuptSML(1) = d11BuptSML_end ;
options_l = optimoptions(@lsqnonlin,'TolFun',1e-9,'TolX',1e-12);
fractwood = zeros(n+1,1);
fractwood(1) = fractwood_end;
Horg = zeros(n+1,1);
Horg(1) = Hs;
   

    
uptake = zeros(n+1,2);
uptake(1,1)= uptake_end(1,1);
uptake(1,2)= uptake_end(1,2);

 for i = 1:n   
  [xxx,resnorm,residual,exitflag,output]=lsqnonlin('Bveg3layer',x0,lb,ub,options_l);
   resisual_tot_3(i,:) = residual;
   resinorm_tot_3(i) = resnorm;
   exitflag_tot_lsqnonlin_3(i) = exitflag;
  x0 = xxx;

    [xxxx,fval,exitflag] = fsolve('Bveg3layer',x0,options);
   xx(i+1,:)= xxxx;
fval_tot_3(:,i) = feval('Bveg3layer', xx(i+1,:)) ;
    exitflag_tot_fslv_3(i) = exitflag;
    if (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11)) < 0
       aa =0;
       bb=0;
   
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  < (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05)))
       aa=1;
       bb=0;
     
   elseif Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))  > (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) && (DEMm-X*eta*xx(i+1,13)*xx(i+1,1) - (1-X)*eta*xx(i+1,14)*xx(i+1,11))*((1-exp(-t/T))^(1/(1+0.05))) > 0
       bb=1;
       aa =0;
       
    end
      
 d11Bex(i+1,1)= (((((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))) + (((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))*((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11))))*((fex/(1-fw))^(-1+alpha2))*(1-fw)^(-1+alpha1)/Rstd-1)*1000;
 Upttot(i+1,1) =(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) +(1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)+ aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin))+(1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin))))+ bb*(((1-exp(-t/T))^(1/(1+0.05)))*DEMm - X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)- (1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)));

fw = (kw*xx(i+1,2)+rap*(1-fex)*Upttot(i+1,1)-rap*kl*xx(i+1,3))/((rap+1)*Upttot(i+1,1));
 fl=1-fex-fw; 
 UptSOL(i+1,1) = (X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,13)*xx(i+1,1)*Hs/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
UptSML(i+1,1) =((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/((1-X)*H*xx(i+1,14)*xx(i+1,11)+(X)*Hs*xx(i+1,13)*xx(i+1,1))*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)));
d11BuptSOL(i+1,1) = (((X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1)*xx(i+1,6) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,6)))/(X*eta*xx(i+1,13)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,1) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*(X*(xx(i+1,1)-Bmin)/(Km+(xx(i+1,1)-Bmin)))) + bb*X*xx(i+1,1)*xx(i+1,13)*Hs/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
d11BuptSML(i+1,1) =((((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11)*xx(i+1,12) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,11)*xx(i+1,14)*H/(X*xx(i+1,1)*xx(i+1,13)*Hs+(1-X)*xx(i+1,11)*xx(i+1,14)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))*(beta2*xx(i+1,12)))/((1-X)*eta*xx(i+1,14)*((1-exp(-t/T))^(1/(1+0.05)))*xx(i+1,11) + (aa*(Jmax*((1-exp(-t/T))^(1/(1+0.05)))*((1-X)*(xx(i+1,11)-Bmin)/(Km+(xx(i+1,11)-Bmin)))) + bb*(1-X)*xx(i+1,14)*xx(i+1,11)*H/(X*xx(i+1,13)*xx(i+1,1)*Hs+(1-X)*xx(i+1,14)*xx(i+1,11)*H)*((1-exp(-t/T))^(1/(1+0.05)))*(DEMm-X*eta*xx(i+1,13)*xx(i+1,1) -(1-X)*eta*xx(i+1,14)*xx(i+1,11)))))/Rstd-1)*1000;
    

xin = xx(i+1,:);
x0 = xin + xx(i+1,:)-xx(i,:);
t = t+dt;

fractwood(i+1) = fw;
tm(i+1) = tm(i)+dt;
Hs = Hsmax*((1-exp(-t/Tsol))^(1/(1+0.05)));
Horg(i+1) = Hs;
loop = loop + 1
uptake(i+1,1) = aa;
uptake(i+1,2) = bb;
 end
 Resultat_3 = zeros(n*dt+1,length([tm(1) xx(1,:) fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)]));
Resultat_3(1,:) = [tm(1) xx(1,1:5) (xx(1,6)./Rstd-1)*1000 (xx(1,7)./Rstd-1)*1000 (xx(1,8)./Rstd-1)*1000 (xx(1,9)./Rstd-1)*1000 (xx(1,10)./Rstd-1)*1000 xx(1,11) (xx(1,12)./Rstd-1)*1000 xx(1,13) xx(1,14) xx(1,15) xx(1,16) (xx(1,17)./Rstd-1)*1000  fractwood(1) UptSOL(1,1) UptSML(1,1) Upttot(1,1) d11Bex(1,1) d11BuptSOL(1,1) d11BuptSML(1,1) uptake(1,:) Horg(1,1)];
for i=1:dt*n
    Resultat_3(i+1,:)=[tm(1/dt*i) xx(1/dt*i,1:5) (xx(1/dt*i,6)./Rstd-1)*1000 (xx(1/dt*i,7)./Rstd-1)*1000 (xx(1/dt*i,8)./Rstd-1)*1000 (xx(1/dt*i,9)./Rstd-1)*1000 (xx(1/dt*i,10)./Rstd-1)*1000 xx(1/dt*i,11) (xx(1/dt*i,12)./Rstd-1)*1000 xx(1/dt*i,13) xx(1/dt*i,14) xx(1/dt*i,15) xx(1/dt*i,16) (xx(1/dt*i,17)./Rstd-1)*1000    fractwood(1/dt*i) UptSOL(1/dt*i,1) UptSML(1/dt*i,1) Upttot(1/dt*i,1) d11Bex(1/dt*i,1) d11BuptSOL(1/dt*i,1) d11BuptSML(1/dt*i,1) uptake(1/dt*i,:) Horg(1/dt*i,1)];
end

Resultat_tot = [Resultat_1;Resultat_2;Resultat_3];
end