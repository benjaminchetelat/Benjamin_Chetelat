function y = Bveg3layerdynhydro(x)
global teta s KS c Infil eta KB Hw dt ker Prec t T H LQ Upt betadec kwld klld fex fw fl kexB  kl kw  Atm  alpha1 alpha  beta2 Ratm  pH Rcw CW xin Hs X aa bb kprel DEMm
%Unknowns
% x(1) Regolith thickness
% x(2) [Na] in pore water
% x(3) [Si] in pore water
% x(4) [Al3+] in pore water
% x(5) [H+] in pore water
% x(6) [TotB] in pore water
% x(7) [Cl] in pore water
% x(8) [Albite] in regolith
% x(9) [Kaolinite solid solution] in regolith
% x(10) B wood stock
% x(11) B leaf stock
% x(12) B wood litter stock
% x(13) B leaf litter stock
% x(14) Si plant stock
% x(15) Si phytolith
% x(16) d11B soil solution
% x(17) d11B wood stock
% x(18) d11B leaf stock
% x(19) d11B wood litter stock
% x(20) d11B leaf litter stock
% x(21) d11B secondary mineral




y(1) = xin(1) + dt*(Infil  -KS*x(1)^c)/(teta*Hs)- x(1);
y(2) = xin(2) + dt*(KS*x(1)^c -KS*x(2)^c)/(teta*H) - x(2);
y(3) = xin(3) + dt*(Atm -(KS*(x(1))^c)*x(3))/(Hs*teta*x(1)) - x(3);
y(4) =xin(4) + dt*((Atm*(Ratm-x(4)))/(x(1)*(Hs*x(3)*teta))) - x(4);
y(5) = xin(5) + dt*((KS*(x(1))^c)*x(3) + CW -Prec -(KS*(x(2))^c)*x(5))/(H*teta*x(2)) - x(5);
y(6) = xin(6) + dt*((KS*(x(1))^c)*x(3)*(x(4)-x(6)) +CW*(Rcw-x(6)) -Prec*(alpha*x(6)-x(6)))/(H*teta*x(2)*x(5)) - x(6);
y(7) = xin(7) + dt*(KS*x(2)^c -KS*x(7)^c)/(teta*Hw) - x(7);
y(8) = xin(8) + dt*((KS*(x(2))^c)*x(5) + CW -Prec -(KS*(x(7))^c)*x(8))/(Hw*teta*x(7)) - x(8);
y(9) = xin(9) + dt*((KS*(x(2))^c)*x(5)*(x(6)-x(9)) +CW*(Rcw-x(9)) -Prec*(alpha*x(9)-x(9)))/(Hw*teta*x(7)*x(8)) - x(9);